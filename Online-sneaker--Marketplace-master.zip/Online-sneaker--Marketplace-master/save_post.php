<?php
    session_start();

    require_once 'connection.php';

    if (isset(($_POST['submit'])) {
        $brand = $_POST["brand"];
        $model = $_POST["model"];
        $colorCode = $_POST["colorCode"];
        $size = $_POST["size"];
        $price = $_POST["price"];
        $date = $_POST["date"];
        $img = $_POST["Image"];
       
        $query = "INSERT INTO `Tensike` (znamka, model, barva, velikost, cena, datum_izdaje, slika) VALUES(:znamka, :model, :barva, :velikost, :cena, :datum_izdaje, :slika)";
		$stmt = $conn->prepare($query);
		$stmt->bindParam(':znamka', $brand);
		$stmt->bindParam(':model', $model);
		$stmt->bindParam(':barva', $colorCode);
		$stmt->bindParam(':velikost', $size);
		$stmt->bindParam(':cena', $price);
        $stmt->bindParam(':datum_izdaje', $date);
		$stmt->bindParam(':slika', $img);
    }
?>
